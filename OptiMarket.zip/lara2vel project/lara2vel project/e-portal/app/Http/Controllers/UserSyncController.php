<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\MongoUser;
use Illuminate\Http\Request;

class UserSyncController extends Controller
{
    public function syncUsers()
    {
        try {
            // Get all MySQL users
            $mysqlUsers = User::all();

            foreach ($mysqlUsers as $user) {
                // Check if user already exists in MongoDB
                $mongoUser = MongoUser::where('email', $user->email)->first();

                if (!$mongoUser) {
                    // Create new user in MongoDB
                    MongoUser::create([
                        'name' => $user->name,
                        'email' => $user->email,
                        'created_at' => $user->created_at
                    ]);
                }
            }

            return response()->json([
                'status' => 'success',
                'message' => 'Users synchronized successfully'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => 'Error synchronizing users: ' . $e->getMessage()
            ], 500);
        }
    }
} 