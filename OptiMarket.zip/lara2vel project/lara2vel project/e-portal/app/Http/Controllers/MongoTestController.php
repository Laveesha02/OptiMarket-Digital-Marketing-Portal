<?php

namespace App\Http\Controllers;

use Exception;
use MongoDB\Client;
use Illuminate\Http\JsonResponse;

class MongoTestController extends Controller
{
    public function testConnection(): JsonResponse
    {
        try {
            // Test MongoDB extension
            if (!extension_loaded('mongodb')) {
                throw new Exception('MongoDB extension is not loaded');
            }

            // Test basic MongoDB connection
            $client = new Client(
                sprintf(
                    'mongodb://%s:%s@%s:%d/%s',
                    env('MONGO_DB_USERNAME'),
                    env('MONGO_DB_PASSWORD'),
                    env('MONGO_DB_HOST'),
                    env('MONGO_DB_PORT'),
                    env('MONGO_DB_DATABASE')
                )
            );

            // Try to list databases to verify connection
            $databaseList = [];
            foreach ($client->listDatabases() as $database) {
                $databaseList[] = $database->getName();
            }

            // Try to insert a test document
            $collection = $client->selectDatabase(env('MONGO_DB_DATABASE'))->selectCollection('test_collection');
            $insertResult = $collection->insertOne(['test' => 'Hello MongoDB', 'date' => new \DateTime()]);

            return response()->json([
                'status' => 'success',
                'message' => 'MongoDB connection successful',
                'databases' => $databaseList,
                'test_insert_id' => (string) $insertResult->getInsertedId(),
                'php_version' => PHP_VERSION,
                'mongodb_extension' => 'Loaded'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => 'MongoDB connection failed',
                'error' => $e->getMessage(),
                'error_type' => get_class($e),
                'php_version' => PHP_VERSION,
                'mongodb_extension' => extension_loaded('mongodb') ? 'Loaded' : 'Not loaded'
            ], 500);
        }
    }
} 