<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use MongoDB\Client;

class MongoDBServiceProvider extends ServiceProvider
{
    public function register()
    {
        $this->app->singleton(Client::class, function ($app) {
            $config = $app['config']['database.connections.mongodb'];
            
            $uri = sprintf(
                'mongodb://%s:%s@%s:%d/%s?authSource=%s',
                $config['username'],
                $config['password'],
                $config['host'],
                $config['port'],
                $config['database'],
                $config['options']['authSource']
            );

            return new Client($uri, [
                'username' => $config['username'],
                'password' => $config['password'],
                'authSource' => $config['options']['authSource']
            ]);
        });
    }

    public function boot()
    {
        //
    }
} 