<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    /** @use HasFactory<\Database\Factories\UserFactory> */
    use HasApiTokens, HasFactory, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var list<string>
     */
    protected $fillable = [
        'name',
        'email',
        'password',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var list<string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * Get the attributes that should be cast.
     *
     * @return array<string, string>
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
        'password' => 'hashed',
    ];

    protected static function boot()
    {
        parent::boot();

        // Create MongoDB user when MySQL user is created
        static::created(function ($user) {
            MongoUser::create([
                'name' => $user->name,
                'email' => $user->email,
                'password' => $user->password,
                'mysql_user_id' => $user->id,
            ]);
        });

        // Update MongoDB user when MySQL user is updated
        static::updated(function ($user) {
            MongoUser::where('mysql_user_id', $user->id)->update([
                'name' => $user->name,
                'email' => $user->email,
                'password' => $user->password,
            ]);
        });

        // Delete MongoDB user when MySQL user is deleted
        static::deleted(function ($user) {
            MongoUser::where('mysql_user_id', $user->id)->delete();
        });
    }
}
